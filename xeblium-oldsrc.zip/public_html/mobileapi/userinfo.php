<?php
header('Content-Type: application/json; charset=UTF-8; X-Robots-Tag: noindex'); 
echo(json_encode([
	"Status" => "OK",
	"UserInfo" => [
		"UserID" => 1,
		"UserName" => "MobileTest",
		"RobuxBalance" => 10000,
		"TicketsBalance" => 10000,
		"IsAnyBuildersClubMember" => false,
		"ThumbnailUrl" => "http://rubloxs.ru/test.png"
	]
],JSON_UNESCAPED_SLASHES));
?>