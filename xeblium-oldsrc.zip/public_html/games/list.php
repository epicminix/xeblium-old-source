<?php require '../Core/navbar.php' ?>
<head>
<meta content="width=device-width; initial-scale=1.0; maximum-scale=1.0;   user-scalable=0;" name="viewport">
<link href="style.css" rel="stylesheet" type="text/css" />
</head>
<body>
<strong><h1>Games<h1></strong>
<img src="http://rubloxs.ru/images/unknown.gif">
<h2>The [REDACED]</h2>
<a href="http://rubloxs.ru/games/start?placeid=1">Join</a>
<img src="http://rubloxs.ru/images/salt.jpg">
<h2>Sell Salt Simulator</h2>
<a href="http://rubloxs.ru/games/start?placeid=1">Join</a>
</body>
<img src="http://rubloxs.ru/images/sss2.png">
<h2>Sell Salt Simulator 2</h2>
<a href="http://rubloxs.ru/games/start?placeid=1">Join</a>
</body>
<?php require '../Core/footer.php' ?>