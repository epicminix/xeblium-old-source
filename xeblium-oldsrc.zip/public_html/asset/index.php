<?php
  // minix was here negas
  $id = (INT)$_GET["id"];
  ob_start();
  
  if (file_exists($id)) {
    header("Content-Type: text/plain");
    echo"\n";
    readfile($id);
    } else {
      header("Location: https://assetdelivery.roblox.com/v1/asset/?id=".$id."&version=1");
      }
  
  $data = ob_get_clean();
$signature;
$key = file_get_contents("PrivateKey.pem"); //if you want to change your private key
openssl_sign($data, $signature, $key, OPENSSL_ALGO_SHA1);
echo "--rbxsig" . sprintf("%%%s%%%s", base64_encode($signature), $data);