<?php include 'loadhtml.php'; ?>
<div id="Footer" class="">
    <div class="FooterNav">
        <a href="#"><b>Privacy Policy</b></a>
        &nbsp;|&nbsp; 
        <a href="#">Advertise with Us</a>
        &nbsp;|&nbsp; 
        <a href="#">Press</a>
        &nbsp;|&nbsp; 
        <a href="#">Contact Us</a>
        &nbsp;|&nbsp;
        <a href="#">About Us</a>
        &nbsp;|&nbsp;
        <a href="$">Blog</a>
        &nbsp;|&nbsp;
        <a href="#">Jobs</a>
        &nbsp;|&nbsp;
        <a href="#">Parents</a>
 <style type="text/css">
        html
        {
                background-color: #e6e6e6;
        }
    </style>
    </div>
     </div>
    <div class="legal">
        <div class="left">

        <div class="right">
            <p class="Legalese">
 <style type="text/css">
        html
        {
                background-color: #e6e6e6;
        }
    </style>
    RUBLOXS, "Online Building Toy", characters, logos, names. We re not affiliated with roblox</a>, ©2013. Patents pending.
    RUBLOXS is not sponsored, authorized or endorsed by any producer of plastic building bricks, including The LEGO Group, MEGA Brands, and K'Nex, and no resemblance to the products of these companies is intended. Use of this site signifies your acceptance of the <a href="/web/20130614024735/http://www.roblox.com/info/terms-of-service" ref="footer-terms">Terms and Conditions</a>.
</p>
 