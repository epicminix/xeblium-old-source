  <?php include 'loadhtml.php'; ?>
  	<div class="site-header">
    <div id="navigation-container">
        <a href="http://www.roblox.com/Default.aspx" class="btn-logo" data-se="nav-logo"></a>
        <div id="navigation-menu">
            <ul>
                <li><a href="http://www.roblox.com/home" ref="nav-myroblox" data-se="nav-myhome">Home</a></li>
                <li><a data-se="nav-games" href="http://www.roblox.com/games" ref="nav-games" title="Games">Games</a> </li>
                <li><a data-se="nav-catalog" href="http://www.roblox.com/Catalog" ref="nav-catalog" title="Catalog">Catalog</a></li>
                
                    <li><a data-se="nav-develop" href="http://www.roblox.com/develop" title="Develop" ref="nav-develop">Develop</a></li>
                
                <li><a data-se="nav-upgrade" href="http://www.roblox.com/Upgrades/BuildersClubMemberships.aspx" title="Builders Club" ref="nav-buildersclub">Builders Club</a></li>
                <li><a data-se="nav-forum" onclick="" href="http://www.roblox.com/Forum/Default.aspx" style="" title="Forum" ref="nav-forum">Forum</a></li>
                <li class="more-list-item" drop-down-nav-button="more-list-item">
                    <div class="more-link-container">
                        <a id="nav-more" title="More" data-se="nav-more" ref="nav-more">More<span id="more-menu-toggle"></span></a> 
                    </div>
                    <div class="dropdownnavcontainer" style="display:none;" drop-down-nav-container="more-list-item">
                        <div class="dropdownmainnav" style="z-index:1023">
                            <a class="dropdownoption" data-se="nav-more-browse" href="http://www.roblox.com/Browse.aspx" title="People" ref="nav-people"><span>People</span></a>
                            <a class="dropdownoption roblox-interstitial" data-se="nav-more-blog" href="http://blog.roblox.com/" title="Blog" ref="nav-news"><span>Blog</span></a>
                            <a class="dropdownoption" data-se="nav-more-help" href="http://www.roblox.com/Help/Builderman.aspx" title="Help" ref="nav-help"><span>Help</span></a>
                            <div style="clear:both;"></div>
                        </div>
                    </div>
                </li>
            </ul>
        </div>

<div id="AlertSpace">
    <div class="AlertItem" style="max-width: 50px;text-align:center;">
        <a id="lsLoginStatus" data-se="nav-logout" class="logoutButton">Logout</a>
    </div>
    <div class="HeaderDivider"></div>
    
    <a data-se="nav-tickets" href="http://www.roblox.com/My/Money.aspx?tab=MyTransactions">
    <div id="TicketsWrapper" class="TicketsAlert AlertItem tooltip-bottom" original-title="Tickets">
        <div class="icons tickets_icon">
        </div>
        <div id="TicketsAlertCaption" class="AlertCaption">70</div>
    </div>
    </a>

    <a data-se="nav-robux" href="http://www.roblox.com/My/Money.aspx?tab=MyTransactions">
    <div id="RobuxWrapper" class="RobuxAlert AlertItem tooltip-bottom" original-title="Robux">
        <div class="icons robux_icon">
        </div>
        <div id="RobuxAlertCaption" class="AlertCaption">0</div>
    </div>
    </a>

    <div class="HeaderDivider"></div>
    
    <a data-se="nav-friends" href="http://www.roblox.com/friends.aspx#FriendRequestsTab">
    <span id="FriendsTextWrapper" class="FriendsAlert AlertItem tooltip-bottom" original-title="1 Friend Requests">
        <div class="icons friends_icon" style="float:none;">
        </div>    
            <div id="FriendsBubble" class="AlertTextWrapper" runat="server">
                <div class="AlertBox Left"></div>
                <div class="AlertBox" style="background-position: right; padding-right: 3px">
                    <div class="AlertText">1</div>
                </div>
            </div>
    </span>
    </a>

    <a data-se="nav-messages" href="http://www.roblox.com/my/messages">
    <span id="MessagesTextWrapper" class="MessageAlert AlertItem tooltip-bottom" original-title="Messages">
        <div class="icons message_icon" style="float:none;">
        </div>
    </span>
    </a>
    <a data-se="nav-login" href="http://www.roblox.com/User.aspx">
        <div id="AuthenticatedUserNameWrapper">
            <div id="AuthenticatedUserName">
                
                <span class="login-span notranslate">
                    <img id="over13icon" src="./ROBLOX.com_files/8ed6b064a35786706f738c0858345c11.png" alt="" style="vertical-align:middle;padding-right:5px;padding-left:0px;" original-title="This is a 13+ account.">
                    what
                </span>
            </div>
        </div> 

    </a>

    <script type="text/javascript">
        ;$(function () {
            $('#over13icon').tipsy({ gravity: 'n' });

            $("#lsLoginStatus").click(
                    function () {
                        var form = $(this).closest('form');
                        if (form.length == 0) {
                            form = $("<form></form>").appendTo("body");
                        }
                        form.attr('action', '/authentication/logout');
                        form.attr('method', 'post');
                        form.submit();
                    }
                );
        });

    </script> 
</div>
    </div>
</div>
<script type="text/javascript">
    $(function () {
        $('.more-list-item').bind('showDropDown', function () {
            var maxWidth = $('#navigation-menu .dropdownnavcontainer').width();
            $('a.dropdownoption span').each(function (index, elem) {
                elem = $(elem);
                if (elem.outerWidth() > maxWidth) {
                    maxWidth = elem.outerWidth();
                }
            });
            maxWidth = maxWidth + 5;
            $('#navigation-menu .dropdownoption').each(function (index, elem) {
                elem = $(elem);
                if (elem.width() < maxWidth) {
                    elem.width(maxWidth);
                }
            });
        });
    });
    
    
</script>
<div class="mySubmenuFixed Redesign">
    <div id="subMenu" class="subMenu">
        <ul>
            <li><a data-se="subnav-profile" href="http://www.roblox.com/User.aspx?submenu=true">Profile</a></li>
            <li><a data-se="subnav-character" href="http://www.roblox.com/My/Character.aspx">Character</a></li>
            <li><a data-se="subnav-friends" href="http://www.roblox.com/My/EditFriends.aspx">Friends</a></li>
            <li><a data-se="subnav-groups" href="http://www.roblox.com/My/Groups.aspx">Groups</a></li>
            <li><a data-se="subnav-inventory" href="http://www.roblox.com/My/Stuff.aspx">Inventory</a></li>
                <li><a data-se="subnav-sets" href="http://www.roblox.com/My/Sets.aspx">Sets</a></li>
            <li><a data-se="subnav-trade" href="http://www.roblox.com/My/Money.aspx?tab=TradeItems">Trade</a></li>
            <li><a data-se="subnav-money" href="http://www.roblox.com/My/Money.aspx?tab=MyTransactions">Money</a></li>
            <li><a data-se="subnav-advertising" href="http://www.roblox.com/develop?Page=ads">Advertising</a></li>
            <li><a data-se="subnav-account" href="http://www.roblox.com/My/Account.aspx">Account</a></li>
        </ul>
    </div>
</div>
<div class="forceSpaceUnderSubmenu">&nbsp;</div> 
            <div class="forceSpace">&nbsp;</div>
        <noscript>&lt;div class="SystemAlert"&gt;&lt;div class="SystemAlertText"&gt;Please enable Javascript to use all the features on this site.&lt;/div&gt;&lt;/div&gt;</noscript>
        <div id="BodyWrapper">
            <div id="RepositionBody">
                <div id="Body" style="width:970px">