<!--Gayblox meta-->
<meta http-equiv="X-UA-Compatible" content="IE=edge,requiresActiveX=true">
    
    <meta http-equiv="Content-Language" content="en-us">
    <meta name="author" content="Brought by minix">
    <meta name="description" content="User-generated MMO gaming site for kids, teens, and adults. Players architect their own worlds. Builders create free online games that simulate the real world. Create and play amazing 3D games. An online gaming cloud and distributed physics engine.">
    <meta name="keywords" content="free games, online games, building games, virtual worlds, free mmo, gaming cloud, physics engine">
    <meta name="viewport" content="width=device-width, initial-scale=1" /> 
    

    <title>RUBLOXS</title>
    <link rel="icon" type="image/vnd.microsoft.icon" href="http://www.roblox.com/favicon.ico">
    <!--Include CSS for website, use php include lol-->
<link rel="stylesheet" href="https://www.roblox.com/CSS/Base/CSS/FetchCSS?path=main___9f842fd9a1a7173bd52d5de5563566b8_m.css">
   
<link rel="stylesheet" href="https://www.roblox.com/CSS/Base/CSS/FetchCSS?path=page___bd540dc4bbc3cb88bfd00f03ec91d022_m.css">
    